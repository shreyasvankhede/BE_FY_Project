import numpy as np
import pandas as pd

# ---------- Settings: change the folder if your CSVs are elsewhere ----------
DIR = "."
F_SAN = f"{DIR}/Works_Sanctioned.csv"
F_COM = f"{DIR}/Works_Completed.csv"
F_EXP = f"{DIR}/Expenditure_on_Completed_and_On-going_Works_as_on_Date.csv"
F_ALLOC = f"{DIR}/Allocated_Limit_for_Honble_MPs__1_.csv"
# Works_Recommended.csv is not used: every recommended work is already in the
# sanctioned file with identical dates and amounts.

ID_RX = r"(WS/\s*MP\d+/\d{4}-\d{4}/\d+)"


def load(path):
    """Read a raw portal CSV and drop the 'Grand Total' row."""
    df = pd.read_csv(path, encoding="utf-8-sig")
    df = df[pd.to_numeric(df["Sr. No."], errors="coerce").notna()].copy()
    df.columns = [c.strip() for c in df.columns]
    return df.drop(columns="Sr. No.")


def clean_id(s):
    return s.str.replace(r"\s+", "", regex=True)


def split_work(df):
    """'Work' column = '<work id>-<work type>'. Split it into two columns."""
    df["work_id"] = clean_id(df["Work"].str.extract(ID_RX)[0])
    df["work_type"] = df["Work"].str.replace(ID_RX + "-", "", regex=True).str.strip()
    return df.drop(columns="Work")


def num(s):
    return pd.to_numeric(s.astype(str).str.replace(",", ""), errors="coerce")


def date(s):
    return pd.to_datetime(s, format="%d-%b-%Y", errors="coerce")


# =====================================================================
# 1. WORK-LEVEL TABLE
# =====================================================================
san = split_work(load(F_SAN))
san = san.rename(columns={
    "Work category": "work_category", "State": "state", "IDA": "ida",
    "Hon'ble Members of Parliament": "mp", "Constituency": "constituency",
    "Work description": "work_description", "Recommended date": "recommended_date",
    "Sanction Date": "sanction_date", "Sanction Amount ( ₹ )": "sanction_amount",
    "Work Status": "work_status",
})
san["recommended_date"] = date(san["recommended_date"])
san["sanction_date"] = date(san["sanction_date"])
san["sanction_amount"] = num(san["sanction_amount"])
san = san.drop_duplicates("work_id").set_index("work_id")

com = split_work(load(F_COM))
com = com.rename(columns={
    "Work Category": "work_category", "State": "state", "IDA": "ida",
    "Work Description": "work_description", "Hon'ble Members of Parliament": "mp",
    "Constituency": "constituency", "Image": "image",
    "Completion Date": "completion_date", "Amount Disbursed ( ₹ )": "amount_disbursed",
})
com["completion_date"] = date(com["completion_date"])
com["amount_disbursed"] = num(com["amount_disbursed"])
com["image_present"] = (~com["image"].isin(["N/A", np.nan])).astype(int)
com = com.drop_duplicates("work_id").set_index("work_id")

# Expenditure: many payment rows per work -> summarise to one row per work
exp = load(F_EXP).rename(columns={
    "State": "state", "Work": "work_type", "Work ID": "work_id", "IDA": "ida",
    "Hon'ble Members of Parliament": "mp", "Constituency": "constituency",
    "Expenditure Date": "pay_date", "Vendor Name": "vendor",
    "Payment Status": "pay_status", "Fund Disbursed Amount ( ₹ )": "pay_amount",
})
exp["work_id"] = clean_id(exp["work_id"])
exp["pay_date"] = date(exp["pay_date"])
exp["pay_amount"] = num(exp["pay_amount"])
exp["vendor"] = exp["vendor"].str.strip().str.upper()
exp["is_dup_row"] = exp.duplicated(["work_id", "pay_date", "vendor", "pay_amount"]).astype(int)

vendor_cnt = exp.groupby("vendor").size()
exp["vendor_n_payments"] = exp["vendor"].map(vendor_cnt)

pay = exp.groupby("work_id").agg(
    n_payments=("pay_amount", "size"),
    total_paid=("pay_amount", "sum"),
    n_vendors=("vendor", "nunique"),
    first_pay_date=("pay_date", "min"),
    n_in_progress=("pay_status", lambda s: (s == "Payment In-Progress").sum()),
    n_dup_payment_rows=("is_dup_row", "sum"),
    min_payment=("pay_amount", "min"),
    max_vendor_payments=("vendor_n_payments", "max"),
)

# Descriptive columns: sanctioned -> completed -> expenditure
ID_COLS = ["work_category", "state", "ida", "mp", "constituency", "work_type"]
base = san.reindex(columns=ID_COLS)
base = base.combine_first(com.reindex(columns=ID_COLS))
base = base.combine_first(
    exp.drop_duplicates("work_id").set_index("work_id").reindex(columns=ID_COLS)
)

works = base.copy()
works["work_description"] = san["work_description"].combine_first(com["work_description"])
works["recommended_date"] = san["recommended_date"]
works["sanction_date"] = san["sanction_date"]
works["sanction_amount"] = san["sanction_amount"]
works["work_status"] = san["work_status"]
works["completion_date"] = com["completion_date"]
works["amount_disbursed"] = com["amount_disbursed"]
works["image_present"] = com["image_present"]
works = works.join(pay)

# Which source files each work appears in
works["in_sanctioned"] = works.index.isin(san.index)
works["in_completed"] = works.index.isin(com.index)
works["in_expenditure"] = works.index.isin(pay.index)

# Key features
works["days_rec_to_sanction"] = (works["sanction_date"] - works["recommended_date"]).dt.days
works["days_sanction_to_completion"] = (works["completion_date"] - works["sanction_date"]).dt.days
works["days_sanction_to_first_pay"] = (works["first_pay_date"] - works["sanction_date"]).dt.days
works["paid_ratio"] = works["total_paid"] / works["sanction_amount"]
works["disbursed_ratio"] = works["amount_disbursed"] / works["sanction_amount"]
works["log_amount"] = np.log1p(works["sanction_amount"].fillna(works["amount_disbursed"]))
works["round_amount"] = (works["sanction_amount"] % 100000 == 0).astype(float)
works.loc[works["sanction_amount"].isna(), "round_amount"] = np.nan
works = works.replace([np.inf, -np.inf], np.nan).reset_index()
works.to_csv("master_works_v2.csv", index=False)

# =====================================================================
# 2. MP / CONSTITUENCY-LEVEL TABLE (fund utilisation)
# =====================================================================
alloc = load(F_ALLOC).rename(columns={
    "State": "state", "Hon'ble Members of Parliaments": "mp",
    "Constituency": "constituency", "Allocated AMOUNT ( ₹ )": "allocated",
})
alloc["allocated"] = num(alloc["allocated"])
alloc = alloc.drop_duplicates("constituency").set_index("constituency")

grp = works.groupby("constituency")
mp = alloc[["state", "mp", "allocated"]].join(pd.DataFrame({
    "n_works": grp.size(),
    "sanctioned_total": grp["sanction_amount"].sum(),
    "median_days_to_sanction": grp["days_rec_to_sanction"].median(),
    "pct_sanctioned_within_1_day": grp["days_rec_to_sanction"].apply(lambda s: (s <= 1).mean()),
    "median_days_to_completion": grp["days_sanction_to_completion"].median(),
}))
paid = exp.groupby("constituency")["pay_amount"].agg(paid_total="sum", n_payments="size")
mp = mp.join(paid)
mp["sanction_utilisation"] = mp["sanctioned_total"] / mp["allocated"]
mp["paid_utilisation"] = mp["paid_total"] / mp["allocated"]
mp.reset_index().to_csv("mp_summary.csv", index=False)

# =====================================================================
# 3. VENDOR TABLE
# =====================================================================
vendor = exp.groupby("vendor").agg(
    n_payments=("pay_amount", "size"),
    n_works=("work_id", "nunique"),
    n_mps=("mp", "nunique"),
    n_states=("state", "nunique"),
    total_paid=("pay_amount", "sum"),
    n_dup_payment_rows=("is_dup_row", "sum"),
).reset_index().sort_values("n_payments", ascending=False)
vendor.to_csv("vendor_summary.csv", index=False)

# =====================================================================
# 4. Sanity report
# =====================================================================
print("works:", works.shape, "| mp:", mp.shape, "| vendor:", vendor.shape)
print("\nSource overlap:")
print(works[["in_sanctioned", "in_completed", "in_expenditure"]].value_counts())
print("\nMP rows with no works matched:", int(mp["n_works"].isna().sum()))
print("\nMissing values (works):")
print(works.isna().sum()[works.isna().sum() > 0])
